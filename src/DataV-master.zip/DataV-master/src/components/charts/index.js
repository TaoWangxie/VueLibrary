import Charts from './src/main.vue'

export default function (Vue) {
  Vue.component(Charts.name, Charts)
}
