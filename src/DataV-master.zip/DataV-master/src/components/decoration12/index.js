import Decoration12 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration12.name, Decoration12)
}
