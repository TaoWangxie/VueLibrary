import Loading from './src/main.vue'

export default function (Vue) {
  Vue.component(Loading.name, Loading)
}
