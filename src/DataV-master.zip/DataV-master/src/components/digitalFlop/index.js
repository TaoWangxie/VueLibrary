import DigitalFlop from './src/main.vue'

export default function (Vue) {
  Vue.component(DigitalFlop.name, DigitalFlop)
}
