import CapsuleChart from './src/main.vue'

export default function (Vue) {
  Vue.component(CapsuleChart.name, CapsuleChart)
}
