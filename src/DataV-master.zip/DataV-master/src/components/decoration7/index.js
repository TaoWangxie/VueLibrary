import Decoration7 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration7.name, Decoration7)
}
