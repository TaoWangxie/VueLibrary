import Decoration8 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration8.name, Decoration8)
}
