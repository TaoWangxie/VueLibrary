import Decoration5 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration5.name, Decoration5)
}
