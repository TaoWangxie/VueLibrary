import FullScreenContainer from './src/main.vue'

export default function (Vue) {
  Vue.component(FullScreenContainer.name, FullScreenContainer)
}
