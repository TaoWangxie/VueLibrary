import BorderBox13 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox13.name, BorderBox13)
}
