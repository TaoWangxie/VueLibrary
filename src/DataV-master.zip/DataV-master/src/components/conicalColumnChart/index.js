import ConicalColumnChart from './src/main.vue'

export default function (Vue) {
  Vue.component(ConicalColumnChart.name, ConicalColumnChart)
}
